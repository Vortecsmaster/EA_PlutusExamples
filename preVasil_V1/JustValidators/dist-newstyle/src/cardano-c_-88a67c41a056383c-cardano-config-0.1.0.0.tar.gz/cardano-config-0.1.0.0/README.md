# Cardano Configuration

[![GitHub CI][github-shield]][github-ci]

This package exposes the types and functions necessary to configure the `cardano-node`.

[github-shield]: https://github.com/input-output-hk/cardano-config/actions/workflows/haskell.yml/badge.svg
[github-ci]: https://github.com/input-output-hk/cardano-config/actions/workflows/haskell.yml
