# Changelog for utxo-index

## Unreleased changes
