# Revision history for trace-dispatcher

## 1.29.0 -- September 2021

* Initial version.
